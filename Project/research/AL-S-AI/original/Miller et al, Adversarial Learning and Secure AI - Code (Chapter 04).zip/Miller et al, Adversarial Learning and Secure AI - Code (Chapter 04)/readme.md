# NROTC project ZOO attack


## Prerequisites

```
pip install torch
pip install torchvision
```

## Task

The only function to complete is the zoo_attack function in zoo_attack.py file

complete the function and get attack success rate larger than 70%.

In the meanwhile make sure that the perturbation added on the original image is not perceptible 

## model weights 
download model weights from https://drive.google.com/file/d/1zaevLM3QyZEyYCK3q7_wB9BUSj_rd4NU/view?usp=sharing


## Disclaimer
The software is for non-commercial, educational use only.
